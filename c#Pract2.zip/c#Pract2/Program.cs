﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;

namespace TextFileAnalyzer
{
    class Program
    {
        static void Main(string[] args)
        {
            // Указываем пути к вашим файлам
            string[] filePaths = new string[]
            {
                "C:/Users/Admin/Desktop/file_1.txt",  // Замените на реальные пути!
                "C:/Users/Admin/Desktop/file_2.txt",
                "C:/Users/Admin/Desktop/file_3.txt",
                "C:/Users/Admin/Desktop/file_4.txt",
                "C:/Users/Admin/Desktop/file_5.txt"
            };

            Console.WriteLine("Анализ текстовых файлов:\n");

            // Синхронный анализ
            long syncTime = Time(() =>
            {
                long totalChars = AnalyzeFilesSync(filePaths);
                Console.WriteLine($"Синхронно:  Количество символов = {totalChars}");
            });
            Console.WriteLine($"Время выполнения синхронно: {syncTime} мс\n");

            // Асинхронный анализ (Task.Run)
            long asyncTime = Time(() =>
            {
                long totalChars = AnalyzeFilesAsync(filePaths).Result;
                Console.WriteLine($"Асинхронно (Task.Run): Количество символов = {totalChars}");
            });
            Console.WriteLine($"Время выполнения асинхронно (Task.Run): {asyncTime} мс\n");

            // Анализ в нескольких потоках
            int numThreads = Environment.ProcessorCount; // Используем количество ядер процессора
            long parallelTime = Time(() =>
            {
                long totalChars = AnalyzeFilesParallel(filePaths, numThreads);
                Console.WriteLine($"Параллельно ({numThreads} потоков): Количество символов = {totalChars}");
            });
            Console.WriteLine($"Время выполнения параллельно ({numThreads} потоков): {parallelTime} мс\n");


            // Асинхронный анализ (async/await)
            long asyncAwaitTime = Time(() =>
            {
                long totalChars = AnalyzeFilesAsyncAwait(filePaths).Result;
                Console.WriteLine($"Асинхронно (async/await): Количество символов = {totalChars}");
            });
            Console.WriteLine($"Время выполнения асинхронно (async/await): {asyncAwaitTime} мс\n");

            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();

            //  Удаляем тестовые файлы - удаляем, если вы их создаете, а если берете файлы откуда-то - то не надо удалять
            // DeleteTestFiles(filePaths);
        }

        // Создание тестовых файлов (закомментируйте!)
        // static string[] CreateTestFiles(int numFiles, int fileSizeInBytes) { ... }

        static void DeleteTestFiles(string[] filePaths)
        {
            foreach (var path in filePaths)
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
        }


        // Синхронный анализ
        static long AnalyzeFilesSync(string[] filePaths)
        {
            long totalChars = 0;
            foreach (string filePath in filePaths)
            {
                try // added
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        while (reader.Peek() >= 0)
                        {
                            reader.Read(); // Читаем по одному символу
                            totalChars++;
                        }
                    }
                }
                catch (Exception ex) // added
                {
                    Console.WriteLine($"Error reading file {filePath}: {ex.Message}"); // added
                }
            }
            return totalChars;
        }

        // Асинхронный анализ (Task.Run)
        static async Task<long> AnalyzeFilesAsync(string[] filePaths)
        {
            long totalChars = 0;
            Task<long>[] tasks = new Task<long>[filePaths.Length];

            for (int i = 0; i < filePaths.Length; i++)
            {
                string filePath = filePaths[i];
                tasks[i] = Task.Run(() =>
                {
                    long fileChars = 0;
                    try // added
                    {
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            while (reader.Peek() >= 0)
                            {
                                reader.Read();
                                fileChars++;
                            }
                        }
                    }
                    catch (Exception ex) // added
                    {
                        Console.WriteLine($"Error reading file {filePath}: {ex.Message}"); // added
                        return 0; // added
                    }
                    return fileChars;
                });
            }

            await Task.WhenAll(tasks);

            foreach (Task<long> task in tasks)
            {
                totalChars += task.Result;
            }

            return totalChars;
        }

        // Асинхронный анализ (async/await)
        static async Task<long> AnalyzeFilesAsyncAwait(string[] filePaths)
        {
            long totalChars = 0;
            Task<long>[] tasks = new Task<long>[filePaths.Length];

            for (int i = 0; i < filePaths.Length; i++)
            {
                string filePath = filePaths[i];
                tasks[i] = ReadFileAndCountCharsAsync(filePath);
            }

            await Task.WhenAll(tasks);

            foreach (Task<long> task in tasks)
            {
                totalChars += task.Result;
            }

            return totalChars;
        }

        static async Task<long> ReadFileAndCountCharsAsync(string filePath)
        {
            long fileChars = 0;
            try // added
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = await reader.ReadLineAsync()) != null)
                    {
                        fileChars += line.Length;
                    }
                }
            }
            catch (Exception ex) // added
            {
                Console.WriteLine($"Error reading file {filePath}: {ex.Message}"); // added
                return 0; // added
            }
            return fileChars;
        }


        // Параллельный анализ
        static long AnalyzeFilesParallel(string[] filePaths, int numThreads)
        {
            long totalChars = 0;
            object lockObject = new object(); // Для синхронизации доступа к totalChars

            Parallel.ForEach(filePaths, new ParallelOptions { MaxDegreeOfParallelism = numThreads }, filePath =>
            {
                long fileChars = 0;
                try // added
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        while (reader.Peek() >= 0)
                        {
                            reader.Read();
                            fileChars++;
                        }
                    }
                }
                catch (Exception ex) // added
                {
                    Console.WriteLine($"Error reading file {filePath}: {ex.Message}"); // added
                    return; // added
                }

                lock (lockObject)
                {
                    totalChars += fileChars;
                }
            });

            return totalChars;
        }


        // Функция для измерения времени выполнения
        static long Time(Action action)
        {
            var stopwatch = Stopwatch.StartNew();
            action();
            stopwatch.Stop();
            return stopwatch.ElapsedMilliseconds;
        }
    }
}
